const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "guilds.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({}, null, 2));

function readAll() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch (e) {
    return {};
  }
}

function writeAll(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

const DEFAULT_CONFIG = {
  enabled: true,
  channelId: null,
  roleId: null,
  message: "🎉 {kullanici}, **{sunucu}** sunucusuna hos geldin! Artik {uye-sayisi}. uyemizsin.",
  imageUrl: null // istege bagli banner/gorsel URL'i
};

function getGuildConfig(guildId) {
  const all = readAll();
  if (!all[guildId]) {
    all[guildId] = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
    writeAll(all);
  } else {
    all[guildId] = { ...JSON.parse(JSON.stringify(DEFAULT_CONFIG)), ...all[guildId] };
  }
  return all[guildId];
}

function saveGuildConfig(guildId, partialConfig) {
  const all = readAll();
  const current = all[guildId] || JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  all[guildId] = { ...current, ...partialConfig };
  writeAll(all);
  return all[guildId];
}

module.exports = { getGuildConfig, saveGuildConfig };
