const { EmbedBuilder } = require("discord.js");

function fillPlaceholders(text, member) {
  return text
    .replaceAll("{kullanici}", `${member}`)
    .replaceAll("{sunucu}", member.guild.name)
    .replaceAll("{uye-sayisi}", `${member.guild.memberCount}`);
}

function buildWelcomeEmbed(cfg, member) {
  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setDescription(fillPlaceholders(cfg.message, member))
    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
    .setTimestamp();

  if (cfg.imageUrl) embed.setImage(cfg.imageUrl);

  return embed;
}

module.exports = { buildWelcomeEmbed, fillPlaceholders };
