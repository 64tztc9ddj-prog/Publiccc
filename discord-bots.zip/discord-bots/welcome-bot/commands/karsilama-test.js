const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { buildWelcomeEmbed } = require("../utils/buildWelcome");
const { getGuildConfig } = require("../database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("karsilama-test")
    .setDescription("Karsilama mesajini kendi uzerinizde test eder")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const cfg = getGuildConfig(interaction.guild.id);
    const embed = buildWelcomeEmbed(cfg, interaction.member);
    await interaction.reply({ content: "Onizleme:", embeds: [embed], ephemeral: true });
  }
};
