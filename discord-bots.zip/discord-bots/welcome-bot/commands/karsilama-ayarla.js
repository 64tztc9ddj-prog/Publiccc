const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require("discord.js");
const { getGuildConfig, saveGuildConfig } = require("../database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("karsilama-ayarla")
    .setDescription("Karsilama mesajini yapilandirir")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName("kanal")
        .setDescription("Karsilama mesajinin gonderilecegi kanal")
        .addChannelOption(o => o.setName("kanal").setDescription("Kanal").addChannelTypes(ChannelType.GuildText).setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("mesaj")
        .setDescription("Karsilama mesajini ayarlar. Degiskenler: {kullanici} {sunucu} {uye-sayisi}")
        .addStringOption(o => o.setName("metin").setDescription("Mesaj metni").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("rol")
        .setDescription("Katilan uyeye otomatik verilecek rol")
        .addRoleOption(o => o.setName("rol").setDescription("Rol").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("gorsel")
        .setDescription("Karsilama mesajina eklenecek gorsel/banner URL'i")
        .addStringOption(o => o.setName("url").setDescription("Gorsel URL'i (bos birakmak icin '-' yazin)").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("ac-kapat")
        .setDescription("Karsilama sistemini acar/kapatir")
        .addBooleanOption(o => o.setName("durum").setDescription("Acik/kapali").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("goster")
        .setDescription("Guncel karsilama ayarlarini gosterir")
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === "kanal") {
      const channel = interaction.options.getChannel("kanal");
      saveGuildConfig(guildId, { channelId: channel.id });
      return interaction.reply({ content: `✅ Karsilama kanali ${channel} olarak ayarlandi.`, ephemeral: true });
    }

    if (sub === "mesaj") {
      const metin = interaction.options.getString("metin");
      saveGuildConfig(guildId, { message: metin });
      return interaction.reply({ content: `✅ Karsilama mesaji guncellendi.`, ephemeral: true });
    }

    if (sub === "rol") {
      const role = interaction.options.getRole("rol");
      saveGuildConfig(guildId, { roleId: role.id });
      return interaction.reply({ content: `✅ Katilan uyelere otomatik **${role.name}** rolu verilecek.`, ephemeral: true });
    }

    if (sub === "gorsel") {
      const url = interaction.options.getString("url");
      saveGuildConfig(guildId, { imageUrl: url === "-" ? null : url });
      return interaction.reply({ content: url === "-" ? "✅ Gorsel kaldirildi." : "✅ Gorsel ayarlandi.", ephemeral: true });
    }

    if (sub === "ac-kapat") {
      const durum = interaction.options.getBoolean("durum");
      saveGuildConfig(guildId, { enabled: durum });
      return interaction.reply({ content: `✅ Karsilama sistemi ${durum ? "aktif" : "pasif"} edildi.`, ephemeral: true });
    }

    if (sub === "goster") {
      const cfg = getGuildConfig(guildId);
      const embed = new EmbedBuilder()
        .setColor(0x9B59B6)
        .setTitle("👋 Karsilama Ayarlari")
        .addFields(
          { name: "Durum", value: cfg.enabled ? "🟢 Aktif" : "🔴 Pasif", inline: true },
          { name: "Kanal", value: cfg.channelId ? `<#${cfg.channelId}>` : "Ayarlanmadi", inline: true },
          { name: "Otomatik Rol", value: cfg.roleId ? `<@&${cfg.roleId}>` : "Yok", inline: true },
          { name: "Mesaj", value: cfg.message },
          { name: "Gorsel", value: cfg.imageUrl || "Yok" }
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
