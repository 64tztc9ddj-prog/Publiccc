const { getGuildConfig } = require("../database");
const { buildWelcomeEmbed } = require("../utils/buildWelcome");

module.exports = {
  name: "guildMemberAdd",
  async execute(member) {
    const cfg = getGuildConfig(member.guild.id);
    if (!cfg.enabled || !cfg.channelId) return;

    const channel = member.guild.channels.cache.get(cfg.channelId);
    if (!channel) return;

    const embed = buildWelcomeEmbed(cfg, member);
    await channel.send({ content: `${member}`, embeds: [embed] }).catch(() => {});

    if (cfg.roleId) {
      const role = member.guild.roles.cache.get(cfg.roleId);
      if (role) await member.roles.add(role).catch(() => {});
    }
  }
};
