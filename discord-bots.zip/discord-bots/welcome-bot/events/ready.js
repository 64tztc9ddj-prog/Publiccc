const { ActivityType } = require("discord.js");

module.exports = {
  name: "ready",
  once: true,
  execute(client) {
    console.log(`✅ Karsilama Botu aktif: ${client.user.tag}`);
    client.user.setPresence({
      activities: [{ name: "yeni uyeleri karsiliyor 👋", type: ActivityType.Playing }],
      status: "online"
    });
  }
};
