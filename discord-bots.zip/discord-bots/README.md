# 1453 AMIGOS Botlari — Kurulum Rehberi

Bu pakette 2 bot var:
- **welcome-bot/** → Sadece karsilama (welcome) mesaji atar
- **main-bot/** → Moderasyon (ban/kick/sustur/uyar) + Anti-Raid Guard + Kayit sistemi + Log — hepsi tek botta

Asagidaki adimlari sirasiyla takip et. Hicbir adimi atlama, ozellikle Privileged Intents kismini.

---

## 1) Discord Developer Portal'da 2 Bot Olustur

Her bot icin ayni adimlari tekrarla (once main-bot icin, sonra welcome-bot icin):

1. https://discord.com/developers/applications adresine git, Discord hesabinla giris yap.
2. **New Application** → isim ver (orn: "1453 Ana Bot") → Create.
3. Sol menuden **Bot** sekmesine git → **Reset Token** / **Copy** ile token'i kopyala. Bunu **kimseyle paylasma**, sonra `.env` dosyasina yapistiracaksin.
4. Ayni sayfada asagi in, **Privileged Gateway Intents** basligi altinda:
   - ✅ **Server Members Intent** — AC (kayit, karsilama, anti-raid icin sart)
   - ✅ **Message Content Intent** — AC (kufur/anti-link filtresi icin sart, sadece main-bot icin gerekli ama ikisinde de acabilirsin)
5. Sol menuden **OAuth2 → URL Generator**'a git:
   - **Scopes**: `bot` ve `applications.commands` isaretle
   - **Bot Permissions**: `Administrator` sec (en kolay yontem; istersen sadece gerekli izinleri de secebilirsin: Ban Members, Kick Members, Moderate Members, Manage Messages, Manage Roles, Manage Guild, View Audit Log, Send Messages, Embed Links)
   - Alttaki linki kopyala, tarayicida ac, botu sunucuna ekle.
6. **General Information** sekmesinden **Application ID**'yi kopyala (bu `CLIENT_ID` olacak).
7. Sunucunda "Ayarlar → Gelismis" kismindan **Developer Mode**'u ac, sonra sunucu ismine sag tikla **ID'yi Kopyala** (bu `GUILD_ID` olacak, komutlarin aninda gorunmesi icin kullanilir).

Bu islemi **iki bot icin de ayri ayri** yap; iki farkli token, iki farkli Application ID elde edeceksin.

---

## 2) GitHub'a Yukle

Railway, GitHub reposundan otomatik deploy yapiyor. Bu yuzden:

1. https://github.com adresinde yeni **iki ayri repo** olustur: `main-bot` ve `welcome-bot` (istersen tek repoda iki klasor de olabilir, Railway'de "Root Directory" ile ayirirsin).
2. Bu klasorleri (main-bot/, welcome-bot/) kendi bilgisayarindan git ile push et:
   ```bash
   cd main-bot
   git init
   git add .
   git commit -m "ilk yukleme"
   git branch -M main
   git remote add origin BURAYA_KENDI_REPO_LINKIN
   git push -u origin main
   ```
   welcome-bot icin de ayni islemi tekrarla.

   > Bilgisayarda git/GitHub kullanmayi bilmiyorsan: GitHub'da repo actiktan sonra "uploading an existing file" linkine tiklayip klasordeki dosyalari surukle-birak ile de yukleyebilirsin (node_modules ve .env dosyasini YUKLEME, zaten .gitignore bunlari haric tutuyor).

---

## 3) Railway'e Deploy Et

1. https://railway.app → GitHub hesabinla giris yap.
2. **New Project → Deploy from GitHub repo** → `main-bot` reponu sec.
3. Deploy basladiginda **Variables** sekmesine git, su degiskenleri ekle:
   - `DISCORD_TOKEN` = main-bot'un token'i
   - `CLIENT_ID` = main-bot'un Application ID'si
   - `GUILD_ID` = sunucu ID'n
4. Ayni sekilde ikinci bir proje ac (**New Project → Deploy from GitHub repo**) ve `welcome-bot` reponu sec, ayni sekilde onun kendi token/CLIENT_ID/GUILD_ID bilgilerini gir.
5. Her iki proje de otomatik `npm install` yapip `node index.js` ile baslayacak (railway.json bunu zaten ayarliyor).

### Slash Komutlarini Kaydetme (ilk kurulumda 1 kere)
Railway panelinde her servis icin sag ustten **Settings → Deploy → Custom Start Command** kismina gecici olarak:
```
node deploy-commands.js && node index.js
```
yaz, bir kere deploy olsun (komutlar Discord'a kaydedilir), sonra tekrar `node index.js` olarak geri al. (Ya da kendi bilgisayarinda bir kere `npm install` + `npm run deploy` calistirip ayni islemi yerel yapabilirsin.)

---

## 4) Mobilden Botu "Daima Aktif" Tutma

Bot artik senin telefonunda calismiyor — **Railway'in sunucusunda 7/24 calisiyor**. Telefonun kapali olsa bile bot acik kalir. Senin yapman gereken tek sey:

- **railway.app** sitesini telefonunda Safari/Chrome'da ac, "Ana ekrana ekle" yaparsan bir uygulama gibi ikon olarak durur (resmi Railway mobil uygulamasi yok ama site mobil uyumlu calisir).
- Oradan istedigin zaman botu **Logs** sekmesinden izleyebilir, **Restart/Remove** ile yeniden baslatabilir, **Variables**'i degistirebilirsin.
- `railway.json` icindeki `restartPolicyType: ON_FAILURE` sayesinde bot cokerse Railway otomatik olarak tekrar baslatir — sen hicbir sey yapmadan.

### Maliyet notu
Railway'de sabit "sonsuz ucretsiz" plan yok: 30 gunluk deneme sonrasi hesabin **Free plan**a (ayda $1 kredi — cok kucuk, tek bot bile zor gider) duser. **7/24 kesintisiz** icin **Hobby plan** ($5/ay, kredi karti gerekiyor) gerekiyor; iki kucuk bot bu $5 kredinin buyuk kismini rahatlikla karsilar. Guncel fiyatlandirmayi https://railway.app/pricing adresinden kontrol et, degismis olabilir.

---

## 5) Komut Listesi

**Ana Bot:**
| Komut | Aciklama |
|---|---|
| `/ban` | Kullaniciyi yasaklar |
| `/kick` | Kullaniciyi atar |
| `/sustur` | Belirli sure susturur (10m, 1h, 1d) |
| `/susturkaldir` | Susturmayi kaldirir |
| `/uyar` | Kullaniciyi uyarir (5 uyaride otomatik 1 saat susturur) |
| `/uyarilar` | Kullanicinin uyarilarini listeler |
| `/uyarsil` | Belirli bir uyariyi siler |
| `/temizle` | Kanaldan toplu mesaj siler |
| `/kayit` | Uyenin kendi kendine kayit rolu almasi |
| `/ayarla log-kanal` | Log kanalini ayarlar |
| `/ayarla kayit-rol` | `/kayit` ile verilecek rolu ayarlar |
| `/ayarla guard` | Anti-raid korumasini ac/kapat |
| `/ayarla kufur-filtre` | Kufur filtresini ac/kapat |
| `/ayarla anti-link` | Davet linki filtresini ac/kapat |
| `/ayarla goster` | Guncel ayarlari gosterir |

Anti-raid guard otomatik calisir: kisa surede cok fazla katilim olursa sunucu dogrulama seviyesini yukseltir ve suphe uyandiran cok yeni hesaplari otomatik atar. Anti-spam da otomatik calisir: hizli mesaj atanlari otomatik susturur.

**Karsilama Botu:**
| Komut | Aciklama |
|---|---|
| `/karsilama-ayarla kanal` | Karsilama kanalini ayarlar |
| `/karsilama-ayarla mesaj` | Mesaj metnini ayarlar (`{kullanici}` `{sunucu}` `{uye-sayisi}` degiskenlerini kullanabilirsin) |
| `/karsilama-ayarla rol` | Katilanlara otomatik verilecek rol |
| `/karsilama-ayarla gorsel` | Karsilama mesajina banner/gorsel ekler |
| `/karsilama-ayarla ac-kapat` | Sistemi ac/kapat |
| `/karsilama-ayarla goster` | Guncel ayarlari gosterir |
| `/karsilama-test` | Mesaji kendi uzerinde onizler |

---

## 6) Kufur Filtresi Listesini Genisletme

`main-bot/utils/kufurListesi.js` dosyasinda birkac ornek kelime var, kendi listeni oraya ekleyebilirsin. Degisiklik yaptiktan sonra GitHub'a push edersen Railway otomatik olarak yeniden deploy eder.

---

## Sorun Giderme

- **Komutlar gorunmuyor** → `deploy-commands.js` calistigindan emin ol, `GUILD_ID` dogru mu kontrol et.
- **Bot cevap vermiyor** → Railway **Logs** sekmesinde hata var mi bak, genelde yanlis TOKEN veya kapali Intent yuzunden olur.
- **"Missing Permissions" hatasi** → Botun rolu, islem yapmak istedigi kullanicinin rolunden **yukarida** olmali (sunucu ayarlari → roller siralamasi).
