// Buraya filtrelenmesini istediginiz kelimeleri kucuk harfle, virgulle ayirarak ekleyebilirsiniz.
// Ornek amacli birkac hafif kelime eklendi, kendi listenizi ozgurce genisletebilirsiniz.
module.exports = [
  "salak",
  "aptal",
  "gerizekali",
  "mal"
  // Buraya istediginiz kadar kelime ekleyebilirsiniz: "kelime1", "kelime2", ...
];
