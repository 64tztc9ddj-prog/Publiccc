// Basit sure parse: "10m", "1h", "2d", "30s"
function ms(input) {
  if (!input) return null;
  const match = String(input).trim().match(/^(\d+)\s*(s|m|h|d)$/i);
  if (!match) return null;
  const value = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  const multipliers = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return value * multipliers[unit];
}

module.exports = ms;
