const { EmbedBuilder } = require("discord.js");
const { getGuildConfig } = require("../database");

module.exports = {
  name: "messageDelete",
  async execute(message) {
    if (!message.guild || message.author?.bot) return;
    const cfg = getGuildConfig(message.guild.id);
    if (!cfg.logChannelId) return;

    const logChannel = message.guild.channels.cache.get(cfg.logChannelId);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor(0x992D22)
      .setTitle("🗑️ Mesaj Silindi")
      .addFields(
        { name: "Yazar", value: message.author ? `${message.author.tag}` : "Bilinmiyor" },
        { name: "Kanal", value: `${message.channel}` },
        { name: "Icerik", value: message.content ? message.content.slice(0, 1000) : "*(icerik yok / embed)*" }
      )
      .setTimestamp();

    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
