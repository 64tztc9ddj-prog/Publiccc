const { getGuildConfig } = require("../database");
const kufurListesi = require("../utils/kufurListesi");

const SPAM_WINDOW_MS = 6000; // 6 saniye
const SPAM_MESSAGE_LIMIT = 5; // 6 saniyede 5+ mesaj = spam
const INVITE_REGEX = /(discord\.gg|discord\.com\/invite|discordapp\.com\/invite)\/[a-zA-Z0-9]+/i;

module.exports = {
  name: "messageCreate",
  async execute(message) {
    if (message.author.bot || !message.guild) return;
    if (message.member?.permissions.has("Administrator")) return; // yoneticileri filtreleme

    const cfg = getGuildConfig(message.guild.id);
    const client = message.client;

    // --- ANTI SPAM ---
    if (cfg.antiSpamEnabled) {
      if (!client.messageTimestamps) client.messageTimestamps = new Map();
      const key = `${message.guild.id}-${message.author.id}`;
      const now = Date.now();
      const arr = (client.messageTimestamps.get(key) || []).filter(t => now - t < SPAM_WINDOW_MS);
      arr.push(now);
      client.messageTimestamps.set(key, arr);

      if (arr.length > SPAM_MESSAGE_LIMIT) {
        const member = message.member;
        if (member && member.moderatable) {
          await member.timeout(5 * 60 * 1000, "Otomatik: spam tespit edildi").catch(() => {});
          await message.channel.send(`🔇 ${message.author}, spam nedeniyle 5 dakika susturuldun.`).catch(() => {});
        }
        client.messageTimestamps.set(key, []);
        const logChannel = cfg.logChannelId ? message.guild.channels.cache.get(cfg.logChannelId) : null;
        if (logChannel) logChannel.send(`🚨 ${message.author.tag} spam nedeniyle otomatik susturuldu.`).catch(() => {});
        return;
      }
    }

    // --- ANTI LINK (izinsiz davet linki) ---
    if (cfg.antiLinkEnabled && INVITE_REGEX.test(message.content)) {
      await message.delete().catch(() => {});
      await message.channel.send(`🔗 ${message.author}, sunucu davet linki paylasimi yasak.`).then(m => setTimeout(() => m.delete().catch(() => {}), 5000)).catch(() => {});
      return;
    }

    // --- KUFUR FILTRESI ---
    if (cfg.kufurFiltreEnabled) {
      const lower = message.content.toLowerCase();
      const found = kufurListesi.find(k => lower.includes(k));
      if (found) {
        await message.delete().catch(() => {});
        await message.channel.send(`🚫 ${message.author}, lutfen uygun dil kullan.`).then(m => setTimeout(() => m.delete().catch(() => {}), 5000)).catch(() => {});
        return;
      }
    }
  }
};
