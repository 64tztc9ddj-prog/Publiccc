const { EmbedBuilder, AuditLogEvent } = require("discord.js");
const { getGuildConfig } = require("../database");

module.exports = {
  name: "guildBanAdd",
  async execute(ban) {
    const cfg = getGuildConfig(ban.guild.id);
    if (!cfg.logChannelId) return;
    const logChannel = ban.guild.channels.cache.get(cfg.logChannelId);
    if (!logChannel) return;

    let executor = null;
    let reason = ban.reason;
    try {
      const fetchedLogs = await ban.guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanAdd, limit: 5 });
      const banLog = fetchedLogs.entries.find(e => e.target?.id === ban.user.id && Date.now() - e.createdTimestamp < 5000);
      if (banLog) {
        executor = banLog.executor;
        reason = reason || banLog.reason;
      }
    } catch (e) {}

    // Eger /ban komutuyla zaten log atildiysa cift log olmasin diye,
    // /ban komutunda embed baslik "Kullanici Yasaklandi" - burada sadece komut disi (manuel discord panelinden) banlar icin ekstra bilgi verir.
    if (executor && executor.bot) return; // botun kendisi zaten logladi

    const embed = new EmbedBuilder()
      .setColor(0xE74C3C)
      .setTitle("🔨 Kullanici Yasaklandi (Discord panelinden)")
      .addFields(
        { name: "Kullanici", value: `${ban.user.tag} (${ban.user.id})` },
        ...(executor ? [{ name: "Yetkili", value: `${executor.tag}` }] : []),
        { name: "Sebep", value: reason || "Belirtilmedi" }
      )
      .setTimestamp();

    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
