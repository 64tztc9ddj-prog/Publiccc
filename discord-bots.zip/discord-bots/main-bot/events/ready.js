const { ActivityType } = require("discord.js");

module.exports = {
  name: "ready",
  once: true,
  execute(client) {
    console.log(`✅ Ana Bot aktif: ${client.user.tag}`);
    client.user.setPresence({
      activities: [{ name: "sunucuyu koruyor 🛡️", type: ActivityType.Watching }],
      status: "online"
    });
  }
};
