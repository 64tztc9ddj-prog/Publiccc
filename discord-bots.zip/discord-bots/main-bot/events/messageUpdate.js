const { EmbedBuilder } = require("discord.js");
const { getGuildConfig } = require("../database");

module.exports = {
  name: "messageUpdate",
  async execute(oldMessage, newMessage) {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;

    const cfg = getGuildConfig(newMessage.guild.id);
    if (!cfg.logChannelId) return;
    const logChannel = newMessage.guild.channels.cache.get(cfg.logChannelId);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor(0xF39C12)
      .setTitle("✏️ Mesaj Duzenlendi")
      .addFields(
        { name: "Yazar", value: `${newMessage.author.tag}` },
        { name: "Kanal", value: `${newMessage.channel}` },
        { name: "Eski Icerik", value: (oldMessage.content || "*(bos)*").slice(0, 500) },
        { name: "Yeni Icerik", value: (newMessage.content || "*(bos)*").slice(0, 500) }
      )
      .setTimestamp();

    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
