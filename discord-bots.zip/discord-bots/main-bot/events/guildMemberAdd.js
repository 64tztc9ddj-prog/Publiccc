const { EmbedBuilder } = require("discord.js");
const { getGuildConfig } = require("../database");

module.exports = {
  name: "guildMemberAdd",
  async execute(member) {
    const cfg = getGuildConfig(member.guild.id);
    if (!cfg.guardEnabled) return;

    const client = member.client;
    if (!client.joinTimestamps) client.joinTimestamps = new Map();
    if (!client.joinTimestamps.has(member.guild.id)) client.joinTimestamps.set(member.guild.id, []);

    const now = Date.now();
    const timestamps = client.joinTimestamps.get(member.guild.id).filter(t => now - t < cfg.guardJoinWindowMs);
    timestamps.push(now);
    client.joinTimestamps.set(member.guild.id, timestamps);

    const logChannel = cfg.logChannelId ? member.guild.channels.cache.get(cfg.logChannelId) : null;

    // hesap yasi kontrolu
    const accountAgeHours = (now - member.user.createdTimestamp) / (1000 * 60 * 60);
    const isSuspiciousAge = accountAgeHours < cfg.guardMinAccountAgeHours;

    // raid tespiti: kisa surede cok fazla katilim
    const isRaid = timestamps.length >= cfg.guardJoinThreshold;

    if (isRaid) {
      // raid alarm: sunucuyu gecici olarak dogrulama seviyesine al
      try {
        await member.guild.setVerificationLevel(4, "Anti-raid: otomatik yuksek dogrulama").catch(() => {});
      } catch (e) {}

      if (logChannel) {
        const alertEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle("🚨 RAID ALGILANDI")
          .setDescription(`Son ${cfg.guardJoinWindowMs / 1000} saniyede **${timestamps.length}** kisi katildi!\nSunucu dogrulama seviyesi otomatik yukseltildi.`)
          .setTimestamp();
        logChannel.send({ embeds: [alertEmbed] }).catch(() => {});
      }

      // supheli yeni hesaplari otomatik at
      if (isSuspiciousAge && member.kickable) {
        await member.kick("Anti-raid: raid sirasinda cok yeni hesap").catch(() => {});
        if (logChannel) {
          logChannel.send(`🛡️ ${member.user.tag} (hesap yasi: ${accountAgeHours.toFixed(1)} saat) raid korumasi nedeniyle atildi.`).catch(() => {});
        }
        return;
      }
    } else if (isSuspiciousAge && logChannel) {
      // raid yok ama hesap cok yeni - sadece bilgi ver
      const embed = new EmbedBuilder()
        .setColor(0xF39C12)
        .setDescription(`⚠️ **${member.user.tag}** katildi, hesap yasi sadece ${accountAgeHours.toFixed(1)} saat. Takip edin.`);
      logChannel.send({ embeds: [embed] }).catch(() => {});
    }
  }
};
