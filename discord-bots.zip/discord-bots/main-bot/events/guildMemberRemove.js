const { EmbedBuilder, AuditLogEvent } = require("discord.js");
const { getGuildConfig } = require("../database");

module.exports = {
  name: "guildMemberRemove",
  async execute(member) {
    const cfg = getGuildConfig(member.guild.id);
    if (!cfg.logChannelId) return;
    const logChannel = member.guild.channels.cache.get(cfg.logChannelId);
    if (!logChannel) return;

    // Kick miydi kontrol et (audit log)
    let isKick = false;
    let executor = null;
    try {
      const fetchedLogs = await member.guild.fetchAuditLogs({ type: AuditLogEvent.MemberKick, limit: 5 });
      const kickLog = fetchedLogs.entries.find(e => e.target?.id === member.id && Date.now() - e.createdTimestamp < 5000);
      if (kickLog) {
        isKick = true;
        executor = kickLog.executor;
      }
    } catch (e) {}

    const embed = new EmbedBuilder()
      .setColor(isKick ? 0xE67E22 : 0x95A5A6)
      .setTitle(isKick ? "👢 Uye Atildi" : "📤 Uye Ayrildi")
      .addFields(
        { name: "Kullanici", value: `${member.user.tag} (${member.id})` },
        ...(executor ? [{ name: "Yetkili", value: `${executor.tag}` }] : [])
      )
      .setTimestamp();

    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
