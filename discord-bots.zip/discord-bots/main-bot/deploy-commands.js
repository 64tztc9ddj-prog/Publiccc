// Bu scripti bir kere calistirarak slash komutlarini Discord'a kaydedersiniz.
// Terminal: node deploy-commands.js
require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { REST, Routes } = require("discord.js");

const commands = [];
const commandsPath = path.join(__dirname, "commands");
const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith(".js"));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if (command.data) commands.push(command.data.toJSON());
}

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`${commands.length} komut kaydediliyor...`);

    if (process.env.GUILD_ID) {
      // Tek sunucuya kaydet - ANINDA gorunur (test icin ideal)
      await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
        { body: commands }
      );
      console.log("✅ Komutlar sunucuya kaydedildi (anlik).");
    } else {
      // Global kayit - tum sunucularda gorunur ama yayilmasi ~1 saat surebilir
      await rest.put(
        Routes.applicationCommands(process.env.CLIENT_ID),
        { body: commands }
      );
      console.log("✅ Komutlar global olarak kaydedildi (yayilmasi 1 saate kadar surebilir).");
    }
  } catch (error) {
    console.error("❌ Komut kaydi basarisiz:", error);
  }
})();
