// database.js
// Basit dosya tabanli veritabani (harici DB gerektirmez, Railway'de sorunsuz calisir)
const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "guilds.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({}, null, 2));

function readAll() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch (e) {
    return {};
  }
}

function writeAll(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

const DEFAULT_CONFIG = {
  logChannelId: null,
  kayitRoleId: null,
  guardEnabled: true,
  guardJoinThreshold: 6, // X kisi
  guardJoinWindowMs: 10000, // Y ms icinde katilirsa raid sayilir
  guardMinAccountAgeHours: 2, // bu saatten daha yeni hesaplar guard modda isaretlenir
  kufurFiltreEnabled: true,
  antiLinkEnabled: true,
  antiSpamEnabled: true,
  warns: {} // { userId: [ {reason, moderatorId, date} ] }
};

function getGuildConfig(guildId) {
  const all = readAll();
  if (!all[guildId]) {
    all[guildId] = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
    writeAll(all);
  } else {
    // eksik alanlari default ile tamamla (guncelleme sonrasi uyumluluk icin)
    all[guildId] = { ...JSON.parse(JSON.stringify(DEFAULT_CONFIG)), ...all[guildId] };
  }
  return all[guildId];
}

function saveGuildConfig(guildId, partialConfig) {
  const all = readAll();
  const current = all[guildId] || JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  all[guildId] = { ...current, ...partialConfig };
  writeAll(all);
  return all[guildId];
}

function addWarn(guildId, userId, warnData) {
  const all = readAll();
  if (!all[guildId]) all[guildId] = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  if (!all[guildId].warns) all[guildId].warns = {};
  if (!all[guildId].warns[userId]) all[guildId].warns[userId] = [];
  all[guildId].warns[userId].push(warnData);
  writeAll(all);
  return all[guildId].warns[userId];
}

function getWarns(guildId, userId) {
  const cfg = getGuildConfig(guildId);
  return (cfg.warns && cfg.warns[userId]) || [];
}

function removeWarn(guildId, userId, index) {
  const all = readAll();
  if (!all[guildId] || !all[guildId].warns || !all[guildId].warns[userId]) return null;
  const removed = all[guildId].warns[userId].splice(index, 1);
  writeAll(all);
  return removed;
}

module.exports = {
  getGuildConfig,
  saveGuildConfig,
  addWarn,
  getWarns,
  removeWarn
};
