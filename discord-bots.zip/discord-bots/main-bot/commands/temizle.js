const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("temizle")
    .setDescription("Bulundugunuz kanaldan mesaj siler")
    .addIntegerOption(o => o.setName("miktar").setDescription("Silinecek mesaj sayisi (1-100)").setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName("kullanici").setDescription("Sadece bu kullanicinin mesajlarini sil").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger("miktar");
    const user = interaction.options.getUser("kullanici");

    await interaction.deferReply({ ephemeral: true });

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    let toDelete = messages;
    if (user) {
      toDelete = messages.filter(m => m.author.id === user.id);
    }
    toDelete = toDelete.first(amount);

    const deleted = await interaction.channel.bulkDelete(toDelete, true).catch(() => null);

    await interaction.editReply({
      content: deleted ? `🧹 ${deleted.size} mesaj silindi.` : "❌ Mesajlar silinemedi (14 gunden eski mesajlar toplu silinemez)."
    });
  }
};
