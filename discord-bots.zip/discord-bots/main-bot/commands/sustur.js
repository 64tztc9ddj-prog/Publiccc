const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const { getGuildConfig } = require("../database");
const ms = require("../utils/ms");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("sustur")
    .setDescription("Bir kullaniciyi belirli sure susturur (timeout)")
    .addUserOption(o => o.setName("kullanici").setDescription("Susturulacak kullanici").setRequired(true))
    .addStringOption(o => o.setName("sure").setDescription("Ornek: 10m, 1h, 1d (max 28d)").setRequired(true))
    .addStringOption(o => o.setName("sebep").setDescription("Susturma sebebi").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("kullanici");
    const sureStr = interaction.options.getString("sure");
    const reason = interaction.options.getString("sebep") || "Sebep belirtilmedi";
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) return interaction.reply({ content: "❌ Kullanici sunucuda bulunamadi.", ephemeral: true });
    if (!member.moderatable) return interaction.reply({ content: "❌ Bu kullaniciyi susturma yetkim yok.", ephemeral: true });

    const durationMs = ms(sureStr);
    if (!durationMs || durationMs <= 0 || durationMs > 28 * 24 * 60 * 60 * 1000) {
      return interaction.reply({ content: "❌ Gecersiz sure. Ornek: 10m, 1h, 1d (max 28 gun)", ephemeral: true });
    }

    await member.timeout(durationMs, `${reason} | Yetkili: ${interaction.user.tag}`);

    const embed = new EmbedBuilder()
      .setColor(0xF1C40F)
      .setTitle("🔇 Kullanici Susturuldu")
      .addFields(
        { name: "Kullanici", value: `${target.tag} (${target.id})` },
        { name: "Yetkili", value: `${interaction.user.tag}` },
        { name: "Sure", value: sureStr },
        { name: "Sebep", value: reason }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    const cfg = getGuildConfig(interaction.guild.id);
    if (cfg.logChannelId) {
      const logChannel = interaction.guild.channels.cache.get(cfg.logChannelId);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
    }
  }
};
