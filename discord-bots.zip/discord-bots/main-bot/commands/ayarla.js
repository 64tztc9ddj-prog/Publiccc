const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require("discord.js");
const { getGuildConfig, saveGuildConfig } = require("../database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ayarla")
    .setDescription("Bot ayarlarini yapilandirir (sadece yetkililer)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName("log-kanal")
        .setDescription("Moderasyon loglarinin gonderilecegi kanali ayarlar")
        .addChannelOption(o => o.setName("kanal").setDescription("Log kanali").addChannelTypes(ChannelType.GuildText).setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("kayit-rol")
        .setDescription("/kayit komutuyla verilecek rolu ayarlar")
        .addRoleOption(o => o.setName("rol").setDescription("Kayit rolu").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("guard")
        .setDescription("Anti-raid korumasini acar/kapatir")
        .addBooleanOption(o => o.setName("durum").setDescription("Acik/kapali").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("kufur-filtre")
        .setDescription("Kufur/hakaret filtresini acar/kapatir")
        .addBooleanOption(o => o.setName("durum").setDescription("Acik/kapali").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("anti-link")
        .setDescription("Izinsiz davet linki filtresini acar/kapatir")
        .addBooleanOption(o => o.setName("durum").setDescription("Acik/kapali").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("goster")
        .setDescription("Guncel ayarlari gosterir")
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === "log-kanal") {
      const channel = interaction.options.getChannel("kanal");
      saveGuildConfig(guildId, { logChannelId: channel.id });
      return interaction.reply({ content: `✅ Log kanali ${channel} olarak ayarlandi.`, ephemeral: true });
    }

    if (sub === "kayit-rol") {
      const role = interaction.options.getRole("rol");
      saveGuildConfig(guildId, { kayitRoleId: role.id });
      return interaction.reply({ content: `✅ Kayit rolu **${role.name}** olarak ayarlandi. Uyeler artik \`/kayit\` yazabilir.`, ephemeral: true });
    }

    if (sub === "guard") {
      const durum = interaction.options.getBoolean("durum");
      saveGuildConfig(guildId, { guardEnabled: durum });
      return interaction.reply({ content: `✅ Anti-raid guard ${durum ? "aktif" : "pasif"} edildi.`, ephemeral: true });
    }

    if (sub === "kufur-filtre") {
      const durum = interaction.options.getBoolean("durum");
      saveGuildConfig(guildId, { kufurFiltreEnabled: durum });
      return interaction.reply({ content: `✅ Kufur filtresi ${durum ? "aktif" : "pasif"} edildi.`, ephemeral: true });
    }

    if (sub === "anti-link") {
      const durum = interaction.options.getBoolean("durum");
      saveGuildConfig(guildId, { antiLinkEnabled: durum });
      return interaction.reply({ content: `✅ Anti-link filtresi ${durum ? "aktif" : "pasif"} edildi.`, ephemeral: true });
    }

    if (sub === "goster") {
      const cfg = getGuildConfig(guildId);
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle("⚙️ Sunucu Ayarlari")
        .addFields(
          { name: "Log Kanali", value: cfg.logChannelId ? `<#${cfg.logChannelId}>` : "Ayarlanmadi", inline: true },
          { name: "Kayit Rolu", value: cfg.kayitRoleId ? `<@&${cfg.kayitRoleId}>` : "Ayarlanmadi", inline: true },
          { name: "Anti-Raid Guard", value: cfg.guardEnabled ? "🟢 Aktif" : "🔴 Pasif", inline: true },
          { name: "Kufur Filtre", value: cfg.kufurFiltreEnabled ? "🟢 Aktif" : "🔴 Pasif", inline: true },
          { name: "Anti-Link", value: cfg.antiLinkEnabled ? "🟢 Aktif" : "🔴 Pasif", inline: true }
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
