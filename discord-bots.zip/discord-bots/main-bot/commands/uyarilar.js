const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { getWarns } = require("../database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("uyarilar")
    .setDescription("Bir kullanicinin uyarilarini listeler")
    .addUserOption(o => o.setName("kullanici").setDescription("Kullanici").setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser("kullanici");
    const warns = getWarns(interaction.guild.id, target.id);

    if (warns.length === 0) {
      return interaction.reply({ content: `✅ ${target.tag} kullanicisinin hic uyarisi yok.`, ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0xF39C12)
      .setTitle(`${target.tag} - Uyari Listesi (${warns.length})`)
      .setDescription(
        warns.map((w, i) => `**#${i}** <@${w.moderatorId}> tarafindan\n📝 ${w.reason}\n🕒 <t:${Math.floor(new Date(w.date).getTime() / 1000)}:R>`).join("\n\n")
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
