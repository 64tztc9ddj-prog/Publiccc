const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { getGuildConfig } = require("../database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kayit")
    .setDescription("Sunucuya kayit olun ve dogrulanmis rolu alin"),

  async execute(interaction) {
    const cfg = getGuildConfig(interaction.guild.id);

    if (!cfg.kayitRoleId) {
      return interaction.reply({ content: "❌ Bu sunucuda kayit rolu ayarlanmamis. Bir yetkili `/ayarla kayit-rol` komutuyla ayarlamali.", ephemeral: true });
    }

    const role = interaction.guild.roles.cache.get(cfg.kayitRoleId);
    if (!role) {
      return interaction.reply({ content: "❌ Ayarlanan kayit rolu bulunamiyor, bir yetkiliye bildirin.", ephemeral: true });
    }

    const member = interaction.member;
    if (member.roles.cache.has(role.id)) {
      return interaction.reply({ content: "✅ Zaten kayitlisiniz!", ephemeral: true });
    }

    await member.roles.add(role).catch(() => null);

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setDescription(`✅ Basariyla kayit oldunuz ve **${role.name}** rolu verildi!`);

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
