const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const { getGuildConfig } = require("../database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setNameLocalizations({ tr: "at" })
    .setDescription("Bir kullaniciyi sunucudan atar")
    .addUserOption(o => o.setName("kullanici").setDescription("Atilacak kullanici").setRequired(true))
    .addStringOption(o => o.setName("sebep").setDescription("Atma sebebi").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("kullanici");
    const reason = interaction.options.getString("sebep") || "Sebep belirtilmedi";
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) return interaction.reply({ content: "❌ Kullanici sunucuda bulunamadi.", ephemeral: true });
    if (!member.kickable) return interaction.reply({ content: "❌ Bu kullaniciyi atma yetkim yok (rol hiyerarsisi).", ephemeral: true });

    await member.kick(`${reason} | Yetkili: ${interaction.user.tag}`);

    const embed = new EmbedBuilder()
      .setColor(0xE67E22)
      .setTitle("👢 Kullanici Atildi")
      .addFields(
        { name: "Kullanici", value: `${target.tag} (${target.id})` },
        { name: "Yetkili", value: `${interaction.user.tag}` },
        { name: "Sebep", value: reason }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    const cfg = getGuildConfig(interaction.guild.id);
    if (cfg.logChannelId) {
      const logChannel = interaction.guild.channels.cache.get(cfg.logChannelId);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
    }
  }
};
