const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { removeWarn, getWarns } = require("../database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("uyarsil")
    .setDescription("Bir kullanicinin belirli uyarisini siler")
    .addUserOption(o => o.setName("kullanici").setDescription("Kullanici").setRequired(true))
    .addIntegerOption(o => o.setName("id").setDescription("/uyarilar komutundaki # numarasi").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("kullanici");
    const index = interaction.options.getInteger("id");

    const current = getWarns(interaction.guild.id, target.id);
    if (index < 0 || index >= current.length) {
      return interaction.reply({ content: "❌ Gecersiz uyari numarasi.", ephemeral: true });
    }

    removeWarn(interaction.guild.id, target.id, index);
    await interaction.reply({ content: `✅ ${target.tag} kullanicisinin #${index} numarali uyarisi silindi.` });
  }
};
