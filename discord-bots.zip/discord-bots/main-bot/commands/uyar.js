const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const { addWarn, getGuildConfig } = require("../database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("uyar")
    .setDescription("Bir kullaniciyi uyarir")
    .addUserOption(o => o.setName("kullanici").setDescription("Uyarilacak kullanici").setRequired(true))
    .addStringOption(o => o.setName("sebep").setDescription("Uyari sebebi").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("kullanici");
    const reason = interaction.options.getString("sebep");

    const warns = addWarn(interaction.guild.id, target.id, {
      reason,
      moderatorId: interaction.user.id,
      date: new Date().toISOString()
    });

    const embed = new EmbedBuilder()
      .setColor(0xF39C12)
      .setTitle("⚠️ Kullanici Uyarildi")
      .addFields(
        { name: "Kullanici", value: `${target.tag} (${target.id})` },
        { name: "Yetkili", value: `${interaction.user.tag}` },
        { name: "Sebep", value: reason },
        { name: "Toplam Uyari", value: `${warns.length}` }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    const cfg = getGuildConfig(interaction.guild.id);
    if (cfg.logChannelId) {
      const logChannel = interaction.guild.channels.cache.get(cfg.logChannelId);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
    }

    // 5+ uyaridan sonra otomatik 1 saat sustur
    if (warns.length >= 5) {
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      if (member && member.moderatable) {
        await member.timeout(60 * 60 * 1000, "5+ uyari - otomatik susturma").catch(() => {});
        interaction.followUp({ content: `🔇 ${target.tag} 5 uyariya ulasti, otomatik olarak 1 saat susturuldu.` });
      }
    }
  }
};
