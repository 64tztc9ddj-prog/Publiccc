const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("susturkaldir")
    .setDescription("Bir kullanicinin susturmasini kaldirir")
    .addUserOption(o => o.setName("kullanici").setDescription("Kullanici").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("kullanici");
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ content: "❌ Kullanici bulunamadi.", ephemeral: true });

    await member.timeout(null, `Susturma kaldirildi | Yetkili: ${interaction.user.tag}`);

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle("🔊 Susturma Kaldirildi")
      .setDescription(`${target.tag} kullanicisinin susturmasi kaldirildi.`)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
