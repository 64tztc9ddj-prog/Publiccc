const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const { getGuildConfig } = require("../database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ban")
    .setNameLocalizations({ tr: "yasakla" })
    .setDescription("Bir kullaniciyi sunucudan yasaklar")
    .addUserOption(o => o.setName("kullanici").setDescription("Yasaklanacak kullanici").setRequired(true))
    .addStringOption(o => o.setName("sebep").setDescription("Yasaklama sebebi").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("kullanici");
    const reason = interaction.options.getString("sebep") || "Sebep belirtilmedi";
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (member && !member.bannable) {
      return interaction.reply({ content: "❌ Bu kullaniciyi yasaklama yetkim yok (rol hiyerarsisi).", ephemeral: true });
    }

    await interaction.guild.members.ban(target.id, { reason: `${reason} | Yetkili: ${interaction.user.tag}` });

    const embed = new EmbedBuilder()
      .setColor(0xE74C3C)
      .setTitle("🔨 Kullanici Yasaklandi")
      .addFields(
        { name: "Kullanici", value: `${target.tag} (${target.id})` },
        { name: "Yetkili", value: `${interaction.user.tag}` },
        { name: "Sebep", value: reason }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    const cfg = getGuildConfig(interaction.guild.id);
    if (cfg.logChannelId) {
      const logChannel = interaction.guild.channels.cache.get(cfg.logChannelId);
      if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
    }
  }
};
